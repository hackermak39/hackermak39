# Akanksha Krishi Seva Kendra — Website

This is a ready-to-preview bilingual (English/Hindi) agriculture-shop website using the supplied logo.

## Included
- Responsive homepage
- Hindi/English language switch
- Product catalogue with search and category filters
- Shopping cart
- WhatsApp cart checkout
- WhatsApp enquiry form
- Call + WhatsApp contact buttons
- Mobile-friendly layout
- Product examples supplied by the shop

## Preview
Open `index.html` in a browser.

## Important before launch
1. Replace/add all products, pack sizes and prices in the `products` array inside `index.html`.
2. Add product photos if desired.
3. Confirm all manufacturer/product information, labels and regulatory details before publishing.
4. Online payment is not enabled in this static version. A payment gateway such as Razorpay/another provider should be connected through a secure backend before taking live payments.
5. For a live store, connect a database/backend for stock, orders, customer accounts, delivery and payment verification.
6. Buy a domain and hosting, then upload the site files.

## Suggested domain names
- akankshakrishiseva.in
- akankshakrishikendra.in
- akankshakrishisevakendra.in
- akankshakrishi.in

Availability must be checked at an accredited .IN registrar before purchase.

## Shop details used
Akanksha Krishi Seva Kendra
Santosh Kushwaha
Targaon, Unnao, Uttar Pradesh
Maddi Kheda, Near Police Chowki, Unnao to Purwa Road, U.P.
Phone/WhatsApp: 8572947171
Established: 2023
